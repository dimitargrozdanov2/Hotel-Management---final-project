﻿// Write your JavaScript code.
$('#admindropdown').on('mouseenter', () => {
    $('#admindropdown-menu').show();
});
$('#admindropdown').on('mouseleave', () => {
    $('#admindropdown-menu').hide();
});