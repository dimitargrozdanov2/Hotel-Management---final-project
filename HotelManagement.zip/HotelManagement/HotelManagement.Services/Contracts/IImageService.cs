﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelManagement.Services.Contracts
{
    interface IImageService
    {
    }
}
