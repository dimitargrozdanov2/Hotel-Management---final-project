﻿using HotelManagement.Data;
using HotelManagement.DataModels;
using HotelManagement.Infrastructure;
using HotelManagement.Services.Contracts;
using HotelManagement.Services.Exceptions;
using HotelManagement.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HotelManagement.Services
{
    public class BusinessService : IBusinessService
    {
        private readonly ApplicationDbContext context;
        private readonly IMappingProvider mappingProvider;

        public BusinessService(ApplicationDbContext context, IMappingProvider mappingProvider)
        {
            this.context = context ?? throw new ArgumentNullException(nameof(context));
            this.mappingProvider = mappingProvider ?? throw new ArgumentNullException(nameof(mappingProvider));
        }

        public async Task<BusinessViewModel> GetBusinessByNameAsync(string name)
        {
            var business = await this.context.Businesses
                .Include(bu => bu.BusinessUnits)
                .Include(i => i.Images)
                .Include(f => f.Feedback)
                    .ThenInclude(r => r.Replies)
                .FirstOrDefaultAsync(b => b.Name == name);

            if (business == null)
            {
                throw new EntityInvalidException($"Business `{name}` does not exist.");
            }
            var mappedBusiness = this.mappingProvider.MapTo<BusinessViewModel>(business);

            return mappedBusiness;
        }

        public async Task<BusinessViewModel> CreateBusinessAsync(string name, string location, string description)
        {
            if (await this.context.Businesses.AnyAsync(m => m.Name == name))
            {
                throw new EntityAlreadyExistsException($"Business with '{name}' name already exist!");
            }

            var business = new Business() { Name = name, Location = location, Description = description};

            await this.context.Businesses.AddAsync(business);
            await this.context.SaveChangesAsync();

            var returnBusiness = this.mappingProvider.MapTo<BusinessViewModel>(business);

            return returnBusiness;
        }
        public async Task<ICollection<BusinessViewModel>> GetBusinesses(string key, string location = null)
        {
            ICollection<Business> businesses = null;

            // // FOR TESTING PURPOSES, DO NOT REMOVE!!!!! // TODO
            //var notes = await this.context.Notes.Include(x => x.Logbook).Include(x => x.Category).Include(x => x.User).ToListAsync();
            //var mappedNotes = this.mappingProvider.MapTo<ICollection<NoteViewModel>>(notes);

            //var users = await this.context.Users.Include(x => x.LogbookManagers).Include(x => x.Notes).ToListAsync();
            //var mappedUsers = this.mappingProvider.MapTo<ICollection<UserViewModel>>(users);

            //var categories = await this.context.Categories.Include(x => x.Notes).ToListAsync();
            //var mappedCategories = this.mappingProvider.MapTo<ICollection<CategoryViewModel>>(categories);

            //var category = new Category()
            //{
            //    Name = "TestNote",
            //    Id = "d31280391391"
            //};

            //var insert = await this.context.Categories.FirstOrDefaultAsync(x => x.Name == "ivanNote");
            //this.context.Categories.Remove(insert);
            //await context.SaveChangesAsync();

            // END OF TEST CODE;

            if (key == "name")
            {
                businesses = await this.context.Businesses
                    .Include(bu => bu.BusinessUnits)
                    .Include(f => f.Feedback)
                        .ThenInclude(r => r.Replies)
                    .Include(i => i.Images)
                    .OrderBy(k => k.Name)
                    .ToListAsync();
            }
            else if (key == "rating")
            {
                businesses = await this.context.Businesses
                    .Include(bu => bu.BusinessUnits)
                    .Include(i => i.Images)
                    .Include(f => f.Feedback)
                        .ThenInclude(r => r.Replies)
                    .OrderByDescending(k => k.Feedback.Sum(x => x.Rating))
                    .ToListAsync();
            }
            else if (key == "date")
            {
                businesses = await this.context.Businesses
                    .Include(bu => bu.BusinessUnits)
                   .Include(i => i.Images)
                   .Include(f => f.Feedback)
                        .ThenInclude(r => r.Replies)
                   .OrderBy(k => k.CreatedOn)
                   .ToListAsync();

            }
            else if (key == "location") // by country mostly
            {
                businesses = await this.context.Businesses
                    .Include(bu => bu.BusinessUnits)
                    .Include(i => i.Images)
                    .Include(f => f.Feedback)
                        .ThenInclude(r => r.Replies)
                    .Where(l => l.Location.Contains(location))
                    .ToListAsync();
            }

            var mappedBusinesses = this.mappingProvider.MapTo<ICollection<BusinessViewModel>>(businesses);

            return mappedBusinesses;
        }
        public async Task<BusinessViewModel> AddImageToBusiness(string name, string imageUrl, IFormFile Image)
        {
            var business = await this.context.Businesses
                .Include(bu => bu.BusinessUnits)
                .Include(i => i.Images)
                .Include(f => f.Feedback)
                .FirstOrDefaultAsync(b => b.Name == name);

            if (business == null)
            {
                throw new EntityInvalidException($"Business `{name}` does not exist.");
            }

            if (!Image.ContentType.Contains("image"))
            {
                throw new EntityInvalidException("Uploaded file must be of type image");
            }

            if (business.Images.Any(x => x.Name == imageUrl))
            {
                throw new EntityAlreadyExistsException($"Business '{name}' already has an image with this name!");
            }

            var image = new Image() { Name = imageUrl };

            business.Images.Add(image);

            await this.context.SaveChangesAsync();

            var returnBusiness = this.mappingProvider.MapTo<BusinessViewModel>(business);

            return returnBusiness;
        }
    }
}
