﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelManagement.DataModels.Enums
{
    public enum PriorityType
    {
        Low,
        Medium,
        High,
        Urgent
    }
}
