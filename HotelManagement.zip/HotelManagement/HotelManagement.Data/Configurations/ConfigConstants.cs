﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelManagement.Data.Configurations
{
    internal class ConfigConstants
    {
        public const int TitleLength = 50;

        public const int NameLength = 50;

        public const int UsernameLength = 50;

        public const int CommentLength = 200;

        public const int TextLength = 200;
    }
}
